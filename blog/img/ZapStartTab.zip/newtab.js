const KEYS = ['1','2','3','4','5','6','7','8','9','0','Q','W','E','R','T','Y','U','I','O','P','A','S','D','F','G','H','J','K','L','Z','X','C','V','B','N','M'];

const keyboardLayout = [
    ['1','2','3','4','5','6','7','8','9','0'],
    ['Q','W','E','R','T','Y','U','I','O','P'],
    ['A','S','D','F','G','H','J','K','L'],
    ['Z','X','C','V','B','N','M']
];

let shortcuts = {};
let shiftDown = false;
let shiftLong = false;
let shiftTimer = null;
let holdKey = null;
let holdTimer = null;
let holdActive = false;
let downKey = null;
let mouseX = 0;
let mouseY = 0;

const keyboardEl = document.getElementById('keyboard');
const timeEl = document.getElementById('time');
const settingsBtn = document.getElementById('settings-btn');
const panel = document.getElementById('link-panel');
const editModal = document.getElementById('edit-modal');
const modalOverlay = document.getElementById('modal-overlay');

function def() { return { primary: null, secondary: [] }; }
function sc(key) {
    if (!shortcuts[key]) shortcuts[key] = def();
    return shortcuts[key];
}
function time() {
    const n = new Date();
    timeEl.textContent = n.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
function favicon(url) {
    try {
        const full = chrome.runtime.getURL('/_favicon/') + '?pageUrl=' + encodeURIComponent(url) + '&size=32';
        return full.replace(/chrome-extension:\/\/[^/]+/, '');
    }
    catch { return ''; }
}
function hasLinks(key) {
    const s = sc(key);
    return (s.primary && s.primary.url) || (s.secondary && s.secondary.length > 0);
}

function render() {
    keyboardEl.innerHTML = '';
    for (const row of keyboardLayout) {
        const r = document.createElement('div');
        r.className = 'kb-row';
        for (const key of row) {
            const s = sc(key);
            const t = document.createElement('div');
            t.className = 'kb-key';
            t.dataset.key = key;
            const l = document.createElement('span');
            l.className = 'kb-key-label';
            l.textContent = key;
            t.appendChild(l);
            if (s.primary) {
                const i = document.createElement('img');
                i.className = 'kb-key-icon';
                i.src = s.primary.icon || favicon(s.primary.url);
                i.alt = ''; i.draggable = false;
                i.onerror = () => { i.style.display = 'none'; };
                t.appendChild(i);
            }
            if (s.secondary && s.secondary.length > 0) {
                const b = document.createElement('span');
                b.className = 'kb-key-badge';
                b.textContent = s.secondary.length;
                t.appendChild(b);
            }
            r.appendChild(t);
        }
        keyboardEl.appendChild(r);
    }
}

function showKb() { keyboardEl.classList.add('visible'); }
function hideKb() { keyboardEl.classList.remove('visible'); hidePanel(); }
function go(url) { if (url) window.location.href = url; }
function goPri(key) { const s = sc(key); if (s.primary && s.primary.url) { go(s.primary.url); return true; } return false; }
function goSec(key, i) { const s = sc(key); if (s.secondary && s.secondary[i] && s.secondary[i].url) { go(s.secondary[i].url); return true; } return false; }

function openPanel(key, ax, ay, source) {
    hidePanel();
    const s = sc(key);

    if (!s.primary && (!s.secondary || s.secondary.length === 0)) return;

    panel.dataset.key = key;

    if (s.primary) {
        const e = document.createElement('div');
        e.className = 'lp-primary';
        e.dataset.action = 'primary';
        const ic = document.createElement('img');
        ic.className = 'lp-icon'; ic.draggable = false;
        ic.src = s.primary.icon || favicon(s.primary.url);
        ic.alt = ''; ic.onerror = () => { ic.style.display = 'none'; };
        e.appendChild(ic);
        const tx = document.createElement('div');
        tx.className = 'lp-text';
        const ti = document.createElement('div');
        ti.className = 'lp-title'; ti.textContent = s.primary.title || 'Primary';
        tx.appendChild(ti);
        const u = document.createElement('div');
        u.className = 'lp-url';
        try { u.textContent = new URL(s.primary.url).hostname; } catch { u.textContent = s.primary.url; }
        tx.appendChild(u);
        e.appendChild(tx);
        e.addEventListener('mouseenter', () => {
            panel.querySelectorAll('.lp-primary,.lp-secondary').forEach(el => el.classList.remove('hover'));
            e.classList.add('hover');
        });
        panel.appendChild(e);
    }

    if (s.secondary) {
        for (let i = 0; i < s.secondary.length; i++) {
            const link = s.secondary[i];
            const e = document.createElement('div');
            e.className = 'lp-secondary';
            e.dataset.action = 'secondary';
            e.dataset.index = i;
            const ic = document.createElement('img');
            ic.className = 'lp-icon'; ic.draggable = false;
            ic.src = link.icon || favicon(link.url);
            ic.alt = ''; ic.onerror = () => { ic.style.display = 'none'; };
            e.appendChild(ic);
            const tx = document.createElement('div');
            tx.className = 'lp-text';
            const ti = document.createElement('div');
            ti.className = 'lp-title'; ti.textContent = link.title || 'Link ' + (i + 1);
            tx.appendChild(ti);
            const u = document.createElement('div');
            u.className = 'lp-url';
            try { u.textContent = new URL(link.url).hostname; } catch { u.textContent = link.url; }
            tx.appendChild(u);
            e.appendChild(tx);
            e.addEventListener('mouseenter', () => {
                panel.querySelectorAll('.lp-primary,.lp-secondary').forEach(el => el.classList.remove('hover'));
                e.classList.add('hover');
            });
            panel.appendChild(e);
        }
    }

    panel.style.display = 'block';
    panel.classList.remove('show');
    document.body.appendChild(panel);

    requestAnimationFrame(() => {
        const pw = panel.offsetWidth;
        const ph = panel.offsetHeight;
        const pri = panel.querySelector('.lp-primary');
        let offY = ph / 2;
        if (pri) offY = pri.offsetTop + pri.offsetHeight / 2;
        let x = ax - pw / 2;
        let y = ay - offY;
        if (x < 8) x = 8;
        if (y < 8) y = 8;
        if (x + pw > innerWidth - 8) x = innerWidth - 8 - pw;
        if (y + ph > innerHeight - 8) y = innerHeight - 8 - ph;
        panel.style.left = x + 'px';
        panel.style.top = y + 'px';
        panel.classList.add('show');
    });
}

function hidePanel() {
    panel.classList.remove('show');
    panel.style.display = 'none';
    panel.innerHTML = '';
    delete panel.dataset.key;
}

// ---- Keyboard events ----

function isInputFocused() {
    const el = document.activeElement;
    return el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable);
}

document.addEventListener('keydown', (e) => {
    if (e.repeat) return;
    if (e.isComposing) return;

    if (e.key === 'Escape') {
        if (editModal.classList.contains('visible')) {
            closeModal();
            return;
        }
        if (panel.dataset.key || shiftDown) {
            hidePanel();
            hideKb();
            shiftDown = false;
            shiftLong = false;
            clearTimeout(shiftTimer);
            clearKbState();
        }
        return;
    }

    if (isInputFocused()) return;

    if (e.key === 'Shift') {
        shiftDown = true;
        showKb();
        shiftTimer = setTimeout(() => { shiftLong = true; }, 600);
        return;
    }

    const key = e.key.toUpperCase();
    if (!KEYS.includes(key)) return;

    e.preventDefault();
    clearTimeout(holdTimer);
    holdKey = key;
    openPanel(key, mouseX, mouseY, 'keyboard');
    const pri = panel.querySelector('.lp-primary');
    if (pri) pri.classList.add('hover');
});

document.addEventListener('keyup', (e) => {
    if (e.isComposing) return;
    if (isInputFocused()) return;

    if (e.key === 'Shift') {
        if (panel.dataset.key) {
            const h = panel.querySelector('.hover');
            if (h) {
                if (h.dataset.action === 'primary') goPri(panel.dataset.key);
                else if (h.dataset.action === 'secondary') goSec(panel.dataset.key, parseInt(h.dataset.index));
            }
        }
        shiftDown = false;
        shiftLong = false;
        clearTimeout(shiftTimer);
        hidePanel();
        hideKb();
        clearKbState();
        return;
    }

    const key = e.key.toUpperCase();
    if (holdKey && key === holdKey) {
        holdKey = null;
        if (!shiftDown) {
            const h = panel.querySelector('.hover');
            if (h) {
                if (h.dataset.action === 'primary') goPri(key);
                else if (h.dataset.action === 'secondary') goSec(key, parseInt(h.dataset.index));
            }
            hidePanel();
        }
    }
});

// ---- Mouse events ----

document.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;

    if (!downKey && !panel.dataset.key) return;
    const items = panel.querySelectorAll('.lp-primary,.lp-secondary');
    let over = false;
    items.forEach(el => {
        const r = el.getBoundingClientRect();
        const hit = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
        el.classList.toggle('hover', hit);
        if (hit) over = true;
    });

    if (downKey && panel.dataset.key && !over) {
        const r = panel.getBoundingClientRect();
        if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) {
            downKey = null;
            hidePanel();
        }
    }
});

keyboardEl.addEventListener('mousedown', (e) => {
    if (e.button !== 0) return;
    const tile = e.target.closest('.kb-key');
    if (!tile) return;
    e.preventDefault();

    const key = tile.dataset.key;
    if (holdKey) return;
    if (!hasLinks(key)) return;

    downKey = key;
    openPanel(key, e.clientX, e.clientY, 'mouse');
});

document.addEventListener('mouseup', (e) => {
    if (e.button !== 0) return;

    if (downKey) {
        const key = downKey;
        const h = panel.querySelector('.hover');
        if (h) {
            if (h.dataset.action === 'primary') goPri(key);
            else if (h.dataset.action === 'secondary') goSec(key, parseInt(h.dataset.index));
        }
        downKey = null;
        hidePanel();
        hideKb();
        return;
    }

    if (panel.dataset.key && !shiftLong && !holdKey) {
        const t = e.target.closest('.kb-key');
        if (!t && !e.target.closest('#link-panel')) hidePanel();
    }
});

keyboardEl.addEventListener('contextmenu', (e) => {
    if (!shiftDown && !shiftLong) return;
    const t = e.target.closest('.kb-key');
    if (!t) return;
    e.preventDefault();
    clearKbState();
    const editKey = t.dataset.key;
    const s = sc(editKey);
    closeModal();
    modalOverlay.classList.add('visible');
    editModal.classList.add('visible');

    const h2 = document.createElement('h2');
    h2.textContent = 'Edit Key: ' + editKey;
    editModal.appendChild(h2);

    const ps = document.createElement('div');
    ps.className = 'edit-section';
    const hp = document.createElement('h3');
    hp.textContent = 'Primary Link';
    ps.appendChild(hp);
    const pu = document.createElement('input');
    pu.id = 'epu'; pu.placeholder = 'URL'; pu.value = s.primary ? s.primary.url : '';
    ps.appendChild(pu);
    const pt = document.createElement('input');
    pt.id = 'ept'; pt.placeholder = 'Title (optional)'; pt.value = s.primary ? (s.primary.title || '') : '';
    ps.appendChild(pt);
    editModal.appendChild(ps);

    const ss = document.createElement('div');
    ss.className = 'edit-section';
    const hs = document.createElement('h3');
    hs.textContent = 'Secondary Links';
    ss.appendChild(hs);
    const sl = document.createElement('div');
    sl.id = 'esl';
    ss.appendChild(sl);
    const ab = document.createElement('button');
    ab.id = 'add-secondary-btn'; ab.textContent = '+ Add Link';
    ab.addEventListener('click', () => addRow(sl, { title: '', url: '' }));
    ss.appendChild(ab);
    editModal.appendChild(ss);

    const ac = document.createElement('div');
    ac.className = 'edit-actions';
    const sb = document.createElement('button');
    sb.textContent = 'Save';
    sb.addEventListener('click', async () => {
        const k = editKey;
        const pu2 = document.getElementById('epu').value.trim();
        const pt2 = document.getElementById('ept').value.trim();
        const pri = pu2 ? { url: pu2, title: pt2 || pu2, icon: favicon(pu2) } : null;
        const rows = document.querySelectorAll('#esl .edit-secondary-row');
        const sec = [];
        rows.forEach(row => {
            const u = row.querySelector('.sec-url').value.trim();
            const t = row.querySelector('.sec-title').value.trim();
            if (u) sec.push({ url: u, title: t || u, icon: favicon(u) });
        });
        shortcuts[k] = { primary: pri, secondary: sec };
        await chrome.storage.sync.set({ shortcuts }).catch(() => {});
        closeModal();
        render();
    });
    ac.appendChild(sb);
    const cb = document.createElement('button');
    cb.textContent = 'Cancel';
    cb.addEventListener('click', closeModal);
    ac.appendChild(cb);
    editModal.appendChild(ac);

    if (s.secondary) s.secondary.forEach(link => addRow(sl, link));
});

function addRow(list, link) {
    const row = document.createElement('div');
    row.className = 'edit-secondary-row';
    const u = document.createElement('input');
    u.className = 'sec-url'; u.placeholder = 'URL'; u.value = link.url || '';
    row.appendChild(u);
    const t = document.createElement('input');
    t.className = 'sec-title'; t.placeholder = 'Title'; t.value = link.title || '';
    row.appendChild(t);
    const r = document.createElement('button');
    r.className = 'remove-sec-btn'; r.textContent = '\u00D7';
    r.addEventListener('click', () => row.remove());
    row.appendChild(r);
    list.appendChild(row);
}

function clearKbState() {
    holdKey = null;
    clearTimeout(holdTimer);
    holdTimer = null;
    holdActive = false;
    downKey = null;
}

function closeModal() {
    editModal.classList.remove('visible');
    editModal.innerHTML = '';
    modalOverlay.classList.remove('visible');
    clearKbState();
}

document.addEventListener('dragstart', (e) => {
    if (e.target.closest('.kb-key') || e.target.closest('#link-panel')) e.preventDefault();
});

modalOverlay.addEventListener('click', closeModal);

// ---- Init ----

(async () => {
    const r = await chrome.storage.sync.get('shortcuts');
    shortcuts = r.shortcuts || {};
    for (const k of KEYS) { if (!shortcuts[k]) shortcuts[k] = def(); }
    time();
    setInterval(time, 1000);
    const dm = window.matchMedia('(prefers-color-scheme: dark)');
    document.body.classList.toggle('dark', dm.matches);
    dm.addEventListener('change', (e) => document.body.classList.toggle('dark', e.matches));
    settingsBtn.addEventListener('click', () => {
        if (chrome.runtime.openOptionsPage) chrome.runtime.openOptionsPage();
        else window.open(chrome.runtime.getURL('options/options.html'));
    });
    render();
})();
