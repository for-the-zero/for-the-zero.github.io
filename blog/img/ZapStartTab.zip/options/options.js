const KEYS = ['1','2','3','4','5','6','7','8','9','0','Q','W','E','R','T','Y','U','I','O','P','A','S','D','F','G','H','J','K','L','Z','X','C','V','B','N','M'];

function cleanIcon(url) {
    return url ? url.replace(/chrome-extension:\/\/[^/]+/, '') : url;
}

function cleanShortcut(s) {
    if (!s) return s;
    if (s.primary && s.primary.icon) s.primary.icon = cleanIcon(s.primary.icon);
    if (s.secondary) s.secondary.forEach(l => { if (l.icon) l.icon = cleanIcon(l.icon); });
    return s;
}

document.querySelector('#export-btn').addEventListener('click', async () => {
    const r = await chrome.storage.sync.get('shortcuts');
    const blob = new Blob([JSON.stringify(r.shortcuts || {}, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'zst-backup.json';
    a.click();
    URL.revokeObjectURL(a.href);
    alert('Exported');
});

document.querySelector('#import-btn').addEventListener('click', () => {
    document.querySelector('#import-file').click();
});

document.querySelector('#import-file').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
        const text = await file.text();
        const data = JSON.parse(text);
        const shortcuts = {};
        for (const key of KEYS) shortcuts[key] = cleanShortcut(data[key]) || { primary: null, secondary: [] };
        await chrome.storage.sync.set({ shortcuts });
        alert('Imported');
    } catch (err) {
        alert('Invalid JSON file');
    }
});

document.querySelector('#reset-btn').addEventListener('click', async () => {
    if (!confirm('Reset all shortcuts to empty? This cannot be undone.')) return;
    const empty = {};
    for (const key of KEYS) empty[key] = { primary: null, secondary: [] };
    await chrome.storage.sync.set({ shortcuts: empty });
    alert('Reset');
});
